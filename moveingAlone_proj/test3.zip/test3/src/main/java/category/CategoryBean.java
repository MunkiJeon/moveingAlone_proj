package category;

public class CategoryBean {
	
	private int lno;
	private String lname;
	private int lstep;
	private int sno;
	private String sname;
	private int sstep;
	
	public int getLno() {
		return lno;
	}
	public void setLno(int lno) {
		this.lno = lno;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public int getLstep() {
		return lstep;
	}
	public void setLstep(int lstep) {
		this.lstep = lstep;
	}
	public int getSno() {
		return sno;
	}
	public void setSno(int sno) {
		this.sno = sno;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public int getSstep() {
		return sstep;
	}
	public void setSstep(int sstep) {
		this.sstep = sstep;
	}
}
