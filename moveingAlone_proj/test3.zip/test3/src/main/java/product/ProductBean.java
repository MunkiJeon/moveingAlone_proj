package product;

public class ProductBean {
	private int no;
	private String lcname;
	private String scname;
	private String name;
	private int oriprice;
	private int discprice;
	private String info; 
	private String mainImgN;
	private String detailImgN1;
	private String detailImgN2;
	private String detailImgN3;
	private String detailImgN4;
	
	public int getNo() {
		return no;
	}
	public void setNo(int no) {
		this.no = no;
	}
	public String getLcname() {
		return lcname;
	}
	public void setLcname(String lcname) {
		this.lcname = lcname;
	}
	public String getScname() {
		return scname;
	}
	public void setScname(String scname) {
		this.scname = scname;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getOriprice() {
		return oriprice;
	}
	public void setOriprice(int oriprice) {
		this.oriprice = oriprice;
	}
	public int getDiscprice() {
		return discprice;
	}
	public void setDiscprice(int discprice) {
		this.discprice = discprice;
	}
	public String getInfo() {
		return info;
	}
	public void setInfo(String info) {
		this.info = info;
	}
	public String getMainImgN() {
		return mainImgN;
	}
	public void setMainImgN(String mainImgN) {
		this.mainImgN = mainImgN;
	}
	public String getDetailImgN1() {
		return detailImgN1;
	}
	public void setDetailImgN1(String detailImgN1) {
		this.detailImgN1 = detailImgN1;
	}
	public String getDetailImgN2() {
		return detailImgN2;
	}
	public void setDetailImgN2(String detailImgN2) {
		this.detailImgN2 = detailImgN2;
	}
	public String getDetailImgN3() {
		return detailImgN3;
	}
	public void setDetailImgN3(String detailImgN3) {
		this.detailImgN3 = detailImgN3;
	}
	public String getDetailImgN4() {
		return detailImgN4;
	}
	public void setDetailImgN4(String detailImgN4) {
		this.detailImgN4 = detailImgN4;
	}
}
